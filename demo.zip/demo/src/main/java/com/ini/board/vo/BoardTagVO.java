package com.ini.board.vo;

import lombok.Data;

@Data
public class BoardTagVO {
    private String tagId;
    private String tagName;
    // getters/setters
}

