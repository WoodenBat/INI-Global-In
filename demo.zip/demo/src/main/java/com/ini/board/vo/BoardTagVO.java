package com.ini.board.vo;

import lombok.Data;

@Data
public class BoardTagVO {

	private final String board_tag;
	private final String board_tag_jp;
	
	private String tagName;
	
	private String name;
    private String color;
}
