package com.ini.board.vo;

import lombok.Data;

@Data
public class BoardTagVO {
    private String boardTag;      // BOARD_TAG
    private String boardTagJp;    // BOARD_TAG_JP
}

