package com.ini.board.vo;

import lombok.Data;

@Data
public class BoardCategoryVO {
    private String categoryId;
    private String categoryName;
    // getters/setters
}
