package com.ini.translate.vo;

import lombok.Data;

@Data
public class TranslateRequest {

	private String input;
}
