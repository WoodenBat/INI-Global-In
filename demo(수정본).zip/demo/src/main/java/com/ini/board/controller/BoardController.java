package com.ini.board.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.ini.board.mapper.BoardMapper;
import com.ini.board.service.BoardService;
import com.ini.board.vo.*;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/board/*")
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;
    private final BoardMapper boardMapper;
    private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

    @Value("${file.upload-path}")
    private String uploadPath;

    // 글 작성 폼
    @GetMapping("/write")
    public String showWriteForm(Model model) {
        model.addAttribute("tags", boardMapper.selectAllBoardTags());
        model.addAttribute("categories", boardMapper.selectAllBoardCategories());
        model.addAttribute("boardDTO", new BoardDTO());
        return "board/write";
    }

    // 글 작성 처리
    @PostMapping("/write")
    public String submitPost(@RequestParam("board_title") String boardTitle,
                             @RequestParam("board_content") String boardContent,
                             @RequestParam("board_category") String boardCategory,
                             @RequestParam("board_tag") String boardTag,
                             HttpSession session) {

        BoardDTO dto = new BoardDTO();
        dto.setBoard_title(boardTitle);
        dto.setBoard_content(boardContent);
        dto.setBoard_category(boardCategory);
        dto.setBoard_tag(boardTag);
        dto.setBoard_views(0);
        dto.setBoard_write_date(new Date());
        dto.setBoard_update_date(new Date());

        String userId = (String) session.getAttribute("loginUser");
        dto.setUser_id(userId != null ? userId : "test");

        boardService.savePost(dto); // board_id 생성됨

        // ✅ summernote 내용에서 <img src="/uploads/xxxx"> 태그 추출
        List<BoardImageDTO> imageList = new ArrayList<>();
        Matcher matcher = Pattern.compile("<img[^>]+src=\"/uploads/([^\"]+)\"").matcher(boardContent);
        while (matcher.find()) {
            String imageFileName = matcher.group(1); // 실제 파일명만 추출
            BoardImageDTO imageDTO = new BoardImageDTO();
            imageDTO.setBoard_id(dto.getBoard_id());
            imageDTO.setImage_path(imageFileName);
            imageDTO.setOriginal_name(imageFileName); // 필요 시 파싱
            imageDTO.setUpload_date(new Date());
            imageList.add(imageDTO);
        }

        if (!imageList.isEmpty()) {
            boardService.saveImages(imageList);
        }

        return "redirect:/board/list";
    }

    // Summernote 이미지 업로드 처리
    @PostMapping("/uploadImage")
    @ResponseBody
    public Map<String, String> uploadImage(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return Map.of("url", "");
        }

        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();

        String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        File destFile = new File(uploadDir, fileName);
        file.transferTo(destFile);

        // 클라이언트는 이 URL을 <img src="">로 사용함
        return Map.of("url", "/uploads/" + fileName);
    }

    // 게시글 목록
    @GetMapping("/list")
    public String postList(@RequestParam(value = "page", defaultValue = "1") int page,
                           @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                           @RequestParam(value = "keyword", required = false) String keyword,
                           @RequestParam(value = "category", required = false) String category,
                           @RequestParam(value = "tag", required = false) String tag,
                           Model model) {

        int totalCount = boardService.getPostCount(keyword, category, tag);
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);
        if (page > totalPages) page = totalPages > 0 ? totalPages : 1;
        int offset = (page - 1) * pageSize;

        List<BoardListDTO> posts = boardService.getPostList(keyword, category, tag, offset, pageSize);

        model.addAttribute("postList", posts);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("keyword", keyword);
        model.addAttribute("category", category);
        model.addAttribute("tag", tag);
        model.addAttribute("tags", boardService.getAllTags());
        model.addAttribute("categories", boardService.getAllCategories());

        return "board/list";
    }

    // 게시글 상세 보기
    @GetMapping("/view/{id}")
    public String viewBoard(@PathVariable("id") int boardId, Model model, HttpSession session) {
        boardService.incrementViews(boardId);
        BoardDetailDTO board = boardService.getPostById(boardId);

        if (board == null) return "redirect:/board/list";
        
        List<BoardImageDTO> images = boardService.getBoardImages(boardId);
        
        if (board.getBoard_content() != null && !board.getBoard_content().contains("<img")) {
            StringBuilder sb = new StringBuilder(board.getBoard_content());
            for (BoardImageDTO image : images) {
                sb.append("<p><img src=\"/uploads/")
                  .append(image.getImage_path())
                  .append("\" style=\"max-width: 100%\"></p>");
            }
            board.setBoard_content(sb.toString());
        }

        String userId = "test";
        Object loginUser = session.getAttribute("loginUser");
        if (loginUser instanceof String) userId = (String) loginUser;

        boolean liked = boardService.hasUserLiked(boardId, userId);
        int likeCount = boardService.getLikeCount(boardId);

        model.addAttribute("board", board);
        model.addAttribute("liked", liked);
        model.addAttribute("likeCount", likeCount);

        return "board/view";
    }
    
 // 게시글 수정 처리
    @PostMapping("/edit")
    public String updatePost(@RequestParam("board_id") Long board_id,
                             @RequestParam("board_title") String board_title,
                             @RequestParam("board_content") String board_content,
                             @RequestParam("board_category") String board_category,
                             @RequestParam("board_tag") String board_tag,
                             HttpSession session) {

        BoardDTO dto = new BoardDTO();
        dto.setBoard_id(board_id.intValue());
        dto.setBoard_title(board_title);
        dto.setBoard_content(board_content);
        dto.setBoard_category(board_category);
        dto.setBoard_tag(board_tag);
        dto.setBoard_update_date(new Date());

        String userId = (String) session.getAttribute("loginUser");
        dto.setUser_id(userId != null ? userId : "test");

        // 이미지 추출 및 DB 저장
        List<BoardImageDTO> imageList = new ArrayList<>();
        Matcher matcher = Pattern.compile("<img[^>]+src=\"/uploads/([^\"]+)\"").matcher(board_content);
        while (matcher.find()) {
            String imageFileName = matcher.group(1);
            BoardImageDTO image = new BoardImageDTO();
            image.setBoard_id(dto.getBoard_id());
            image.setImage_path(imageFileName);
            image.setOriginal_name(imageFileName);
            image.setUpload_date(new Date());
            imageList.add(image);
        }

        dto.setImageList(imageList);

        boardService.updatePost(dto);

        return "redirect:/board/view/" + board_id;
    }
    
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") int boardId, Model model) {
        BoardDetailDTO post = boardService.getPostById(boardId);
        if (post == null) return "redirect:/board/list";

        model.addAttribute("post", post);
        model.addAttribute("tags", boardMapper.selectAllBoardTags());
        model.addAttribute("categories", boardMapper.selectAllBoardCategories());

        return "board/edit";
    }

    // 게시글 삭제
    @PostMapping("/delete/{id}")
    public String deletePost(@PathVariable("id") int boardId, HttpSession session) {
        String userId = (String) session.getAttribute("loginUser");
        BoardDetailDTO post = boardService.getBoardById(boardId, userId);
        if (post == null || (userId != null && !userId.equals(post.getUser_id()))) {
            return "redirect:/board/list";
        }
        boardService.deletePost(boardId);
        return "redirect:/board/list";
    }

    // 좋아요
    @PostMapping("/like/{boardId}")
    @ResponseBody
    public ResponseEntity<?> toggleLike(@PathVariable("boardId") int boardId, HttpSession session) {
        String userId = (String) session.getAttribute("loginUser");
        if (userId == null) {
            userId = "test";
            session.setAttribute("loginUser", userId);
        }
        int likeCount = boardService.toggleLike(boardId, userId);
        boolean liked = boardService.hasUserLiked(boardId, userId);
        return ResponseEntity.ok().body(Map.of("likeCount", likeCount, "liked", liked));
    }

    // 신고
    @PostMapping("/report")
    public ResponseEntity<?> reportPost(@RequestBody BoardReportDTO report, HttpSession session) {
        String userId = (String) session.getAttribute("loginUser");
        if (userId == null) userId = "test";
        report.setReport_user(userId);

        boolean success = boardService.addReport(report);
        return success ? ResponseEntity.ok().body("신고가 접수되었습니다.") :
                         ResponseEntity.badRequest().body("이미 신고한 게시글입니다.");
    }
}